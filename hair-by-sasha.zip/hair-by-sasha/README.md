# Hair by Sasha — Official Website

Professional hair styling website for **Hair by Sasha**, Winnipeg's luxury mobile hairstylist.

## 🚀 Deploying to GitHub Pages

1. Create a new GitHub repository (e.g. `hair-by-sasha`)
2. Upload all files from this folder into the repo root
3. Go to **Settings → Pages**
4. Under **Source**, select `main` branch → `/ (root)` → Save
5. Your site will be live at `https://yourusername.github.io/hair-by-sasha/`

## 📁 Files

- `index.html` — Main website
- `1781233856550_image.png` — Hero braids photo (used as hero image)
- `1781234003291_image.png` — Box braids gallery photo
- `1781234150420_image.png` — Children's cornrows gallery photo

## 💡 Customization Tips

- **Add more photos:** Drop `.jpg` or `.png` files in the folder and update the `<img>` tags in the gallery section
- **Update Instagram handle:** Search for `@HairbySasha` and replace with your actual handle, linking to your profile
- **Add pricing:** Edit the service cards in the `#services` section to include prices
- **Google Maps embed:** Replace the address text in `#hours` with an embedded Google Maps iframe for a "get directions" button

## 📞 Contact Info on Site

- Phone: (437) 677-6601
- Location: Charles St, Winnipeg, MB R2W 4B9

---
Built with pure HTML/CSS — no dependencies, loads instantly.
